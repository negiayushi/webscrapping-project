from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import time
import json

def scroll_to_element_with_offset(driver, element, offset=100):
    y = element.location['y']
    driver.execute_script(f"window.scrollTo(0, {y - offset});")

def get_detail_by_label(container, label):
    try:
        patterns = [
            f".//label[contains(text(),'{label}')]/following-sibling::strong",
            f".//label[text()='{label}']/following-sibling::strong",
            f".//div[.//label[contains(text(),'{label}')]]//strong"
        ]
        
        for pattern in patterns:
            try:
                element = container.find_element(By.XPATH, pattern)
                text = element.text.strip()
                if text and text != "--":
                    return text
            except NoSuchElementException:
                continue
        return ""
    except Exception:
        return ""

def extract_project_details(driver, wait):
    """Extract details from the current project detail page"""
    try:
        # STEP 1: Extract Project Overview details (RERA No. and Project Name)
        overview_card = wait.until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div.card-body"))
        )
        
        # Extract from Project Overview tab
        rera_reg_no = get_detail_by_label(overview_card, "RERA Regd. No.")
        project_name = get_detail_by_label(overview_card, "Project Name")

        # STEP 2: Navigate to Promoter Details tab
        promoter_tab = driver.find_element(By.ID, "ngb-nav-1")
        scroll_to_element_with_offset(driver, promoter_tab, offset=100)
        time.sleep(0.5)
        driver.execute_script("arguments[0].click();", promoter_tab)

        # Wait for promoter tab content to load
        try:
            wait.until(EC.invisibility_of_element_located((By.CSS_SELECTOR, "ngx-ui-loader .ngx-overlay")))
        except TimeoutException:
            pass
        
        time.sleep(2)

        # Extract from Promoter Details tab
        promoter_card = wait.until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "div.card-body"))
        )

        company_name = get_detail_by_label(promoter_card, "Company Name")
        registered_office_address = get_detail_by_label(promoter_card, "Registered Office Address")
        gst_no = get_detail_by_label(promoter_card, "GST No.")

        return {
            "rera_registration_no": rera_reg_no,
            "project_name": project_name,
            "promoter_name": company_name,
            "promoter_address": registered_office_address,
            "gst_no": gst_no
        }
    
    except Exception as e:
        print(f"Error extracting project details: {e}")
        return None

# Setup Chrome options
options = Options()
# options.add_argument("--headless")
# options.add_argument("--disable-gpu")
options.add_argument("--start-maximized")
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option('useAutomationExtension', False)

driver = webdriver.Chrome(service=Service(), options=options)
all_projects_data = []

try:
    driver.get("https://rera.odisha.gov.in/projects/project-list")
    wait = WebDriverWait(driver, 20)

    # Wait for project cards to load
    project_cards = wait.until(
        EC.presence_of_all_elements_located((By.CLASS_NAME, "project-card"))
    )
    
    print(f"Found {len(project_cards)} project cards")
    
    # Process top 6 projects
    for i in range(min(6, len(project_cards))):
        try:
            print(f"\n--- Processing Project {i+1}/6 ---")
            
            # Go back to main page if not on first iteration
            if i > 0:
                driver.get("https://rera.odisha.gov.in/projects/project-list")
                # Wait for page to reload
                project_cards = wait.until(
                    EC.presence_of_all_elements_located((By.CLASS_NAME, "project-card"))
                )
                time.sleep(2)
            
            # Find the current project card
            current_project_card = project_cards[i]
            
            # Scroll to the project card
            scroll_to_element_with_offset(driver, current_project_card, offset=100)
            time.sleep(1)
            
            # Find and click View Details button
            view_details_button = current_project_card.find_element(By.XPATH, './/a[contains(text(), "View Details")]')
            driver.execute_script("arguments[0].click();", view_details_button)
            
            # Wait for project details page to load
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "ul.nav-tabs.project-details-tab")))
            time.sleep(2)
            
            # Extract project details
            project_data = extract_project_details(driver, wait)
            
            if project_data:
                all_projects_data.append(project_data)
                print(f"✓ Successfully extracted data for project {i+1}")
                print(f"  Project: {project_data['project_name']}")
                print(f"  RERA No: {project_data['rera_registration_no']}")
            else:
                print(f"✗ Failed to extract data for project {i+1}")
                
        except Exception as e:
            print(f"✗ Error processing project {i+1}: {e}")
            continue

    # FINAL OUTPUT - Display all extracted data
    print("\n" + "="*80)
    print("EXTRACTED RERA PROJECT DETAILS - TOP 6 PROJECTS")
    print("="*80)
    
    for idx, project in enumerate(all_projects_data, 1):
        print(f"\n--- PROJECT {idx} ---")
        print(f"RERA Registration No.: {project['rera_registration_no']}")
        print(f"Project Name: {project['project_name']}")
        print(f"Promoter Name: {project['promoter_name']}")
        print(f"Address of Promoter: {project['promoter_address']}")
        print(f"GST No.: {project['gst_no']}")
        print("-" * 50)
    
    print(f"\nTotal projects successfully extracted: {len(all_projects_data)}/6")
    print("="*80)
    
    # Save to JSON file for further processing
    with open('rera_top6_projects.json', 'w', encoding='utf-8') as f:
        json.dump(all_projects_data, f, indent=2, ensure_ascii=False)
    
    print(f"\nData saved to 'rera_top6_projects.json'")

except Exception as e:
    print(f"Main Error: {e}")
    import traceback
    traceback.print_exc()

finally:
    driver.quit()
    print(f"\nScraping completed. Total projects extracted: {len(all_projects_data)}")